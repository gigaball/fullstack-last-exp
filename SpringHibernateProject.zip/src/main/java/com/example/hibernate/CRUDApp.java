package com.example.hibernate;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUDApp {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();

        // CREATE
        Transaction tx = session.beginTransaction();
        Student s1 = new Student("Abhay", "Spring & Hibernate");
        session.save(s1);
        tx.commit();

        // READ
        Student student = session.get(Student.class, s1.getId());
        System.out.println("Fetched Student: " + student);

        // UPDATE
        tx = session.beginTransaction();
        student.setCourse("Advanced Spring");
        session.update(student);
        tx.commit();

        // DELETE
        tx = session.beginTransaction();
        session.delete(student);
        tx.commit();

        session.close();
    }
}
