package com.example.di;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {
    @Autowired
    private Course course;

    public void showDetails() {
        System.out.println("Student enrolled in: " + course.getCourseName());
    }
}
