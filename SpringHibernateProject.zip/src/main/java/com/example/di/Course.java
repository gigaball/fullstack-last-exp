package com.example.di;

public class Course {
    private String courseName = "Spring Framework Basics";

    public String getCourseName() {
        return courseName;
    }
}
