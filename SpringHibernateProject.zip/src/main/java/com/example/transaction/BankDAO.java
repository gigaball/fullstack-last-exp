package com.example.transaction;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

@Repository
public class BankDAO {
    @PersistenceContext
    private EntityManager em;

    public Account getAccount(int id) {
        return em.find(Account.class, id);
    }

    public void updateAccount(Account acc) {
        em.merge(acc);
    }

    public void saveTransaction(TransactionRecord record) {
        em.persist(record);
    }
}
