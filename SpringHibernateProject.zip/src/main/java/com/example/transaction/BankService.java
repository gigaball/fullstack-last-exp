package com.example.transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BankService {

    @Autowired
    private BankDAO dao;

    @Transactional
    public void transferMoney(int fromId, int toId, double amount) {
        Account from = dao.getAccount(fromId);
        Account to = dao.getAccount(toId);

        if (from.getBalance() < amount)
            throw new RuntimeException("Insufficient balance!");

        from.setBalance(from.getBalance() - amount);
        to.setBalance(to.getBalance() + amount);

        dao.updateAccount(from);
        dao.updateAccount(to);

        TransactionRecord record = new TransactionRecord();
        record.setFromAccount(fromId);
        record.setToAccount(toId);
        record.setAmount(amount);
        dao.saveTransaction(record);

        System.out.println("Transaction Successful!");
    }
}
