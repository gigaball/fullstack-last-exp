package com.example.transaction;

import jakarta.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {
    @Id
    private int id;
    private String owner;
    private double balance;
}
